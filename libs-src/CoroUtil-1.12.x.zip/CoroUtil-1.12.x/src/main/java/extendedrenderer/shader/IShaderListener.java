package extendedrenderer.shader;

public interface IShaderListener {

    void init();
    void reset();

}
