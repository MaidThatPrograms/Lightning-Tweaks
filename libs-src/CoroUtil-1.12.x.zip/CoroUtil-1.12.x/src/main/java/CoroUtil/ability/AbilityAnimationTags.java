package CoroUtil.ability;

public class AbilityAnimationTags {

	public static String armLeft = "armLeft";
	public static String armRight = "armRight";
	
}
