package CoroUtil.ability;


public interface IAbilityUsageCallback {

	public void abilityFinished(Ability parAbility);
	
}
