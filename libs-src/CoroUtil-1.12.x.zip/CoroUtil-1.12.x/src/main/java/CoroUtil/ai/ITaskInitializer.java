package CoroUtil.ai;

import net.minecraft.entity.EntityCreature;

public interface ITaskInitializer {

	public void setEntity(EntityCreature creature);
	
}
