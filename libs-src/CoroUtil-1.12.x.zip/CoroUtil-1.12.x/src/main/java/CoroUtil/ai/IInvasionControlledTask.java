package CoroUtil.ai;

public interface IInvasionControlledTask {

    boolean shouldBeRemoved();

}
