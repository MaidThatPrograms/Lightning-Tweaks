package CoroUtil.client;

import java.util.List;

public interface IScrollingElement {

	public String getTitle();
	public String getExtraInfo();
	public List<String> getExtraInfo2();
	
}
