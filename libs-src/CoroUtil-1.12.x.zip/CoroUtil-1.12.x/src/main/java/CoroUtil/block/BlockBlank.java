package CoroUtil.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockBlank extends Block {

    public BlockBlank(Material materialIn) {
        super(materialIn);
    }
}
