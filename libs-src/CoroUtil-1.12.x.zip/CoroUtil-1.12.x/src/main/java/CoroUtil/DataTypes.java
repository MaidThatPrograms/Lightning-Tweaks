package CoroUtil;

public enum DataTypes {
	noMoveTicks, noSeeTicks, followTarg, shouldDespawn;
}
