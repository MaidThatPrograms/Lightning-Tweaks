@API(apiVersion = CoroUtilInfoAPI.VERSION, owner = "CoroAI", provides = "CoroAI|dynamicdifficulty")
package CoroUtil.api.dynamicdifficulty;

import net.minecraftforge.fml.common.API;
import CoroUtil.forge.CoroUtilInfoAPI;

