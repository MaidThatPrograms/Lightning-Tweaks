package CoroUtil.api.weather;

public interface IWindHandler {
	
	float getWindWeight();
	
	int getParticleDecayExtra();

}
