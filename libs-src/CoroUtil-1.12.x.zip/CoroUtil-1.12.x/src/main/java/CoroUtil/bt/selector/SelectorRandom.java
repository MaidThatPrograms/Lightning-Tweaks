package CoroUtil.bt.selector;

import CoroUtil.bt.Behavior;

public class SelectorRandom extends Selector {

	public SelectorRandom(Behavior parParent) {
		super(parParent);
	}
	
}
