package CoroUtil.bt.leaf;

import CoroUtil.bt.Behavior;

public class Leaf extends Behavior {

	public Leaf(Behavior parParent) {
		super(parParent);
	}

}
