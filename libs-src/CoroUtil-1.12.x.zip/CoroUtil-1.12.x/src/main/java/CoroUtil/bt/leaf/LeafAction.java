package CoroUtil.bt.leaf;

import CoroUtil.bt.Behavior;

public class LeafAction extends Leaf {

	public LeafAction(Behavior parParent) {
		super(parParent);
	}

}
