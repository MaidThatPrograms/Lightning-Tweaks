package CoroUtil.bt.leaf;

import CoroUtil.bt.Behavior;

public class LeafCondition extends Leaf {

	public LeafCondition(Behavior parParent) {
		super(parParent);
	}

}
