package CoroUtil.entity;


public class InfoArea 
{
	public int blockID;
	public int x;
	public int y;
	public int z;
	
	public InfoArea(int x, int y, int z, int id) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.blockID = id;
	}
}
