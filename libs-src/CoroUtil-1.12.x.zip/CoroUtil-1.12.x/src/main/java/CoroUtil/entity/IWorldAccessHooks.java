package CoroUtil.entity;

public interface IWorldAccessHooks {

    void onEntityRemoved();

}
