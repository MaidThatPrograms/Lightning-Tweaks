package CoroUtil.forge;

public class CoroUtilInfoAPI {

	public static final String VERSION = "1.0";
	
}
