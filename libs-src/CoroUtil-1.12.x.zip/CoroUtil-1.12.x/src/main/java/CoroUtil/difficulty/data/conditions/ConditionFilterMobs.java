package CoroUtil.difficulty.data.conditions;

import CoroUtil.difficulty.data.DataCondition;

import java.util.List;

/**
 * Created by Corosus on 2/26/2017.
 */
public class ConditionFilterMobs extends DataCondition {
    public String mode;
    public List<String> entities;
}
