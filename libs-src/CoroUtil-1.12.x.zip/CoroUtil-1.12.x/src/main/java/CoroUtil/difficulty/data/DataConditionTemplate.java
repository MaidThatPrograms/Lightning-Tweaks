package CoroUtil.difficulty.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Corosus on 2/26/2017.
 */
public class DataConditionTemplate {

    public String name;
    public List<DataCondition> conditions = new ArrayList<>();

}
