package CoroUtil.difficulty.data.cmods;

import CoroUtil.difficulty.data.DataCmod;

/**
 * Created by Corosus on 2/26/2017.
 */
public class CmodAttributeHealth extends CmodAttributeBaseSimple {

}
