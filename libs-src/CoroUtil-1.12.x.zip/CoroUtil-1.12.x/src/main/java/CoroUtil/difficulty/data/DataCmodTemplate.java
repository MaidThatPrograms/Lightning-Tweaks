package CoroUtil.difficulty.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Corosus on 2/26/2017.
 */
public class DataCmodTemplate {

    public String name;
    public List<DataCmod> cmods = new ArrayList<>();

}
