package CoroUtil.difficulty.data.cmods;

/**
 * Created by Corosus on 2/26/2017.
 */
public class CmodAttributeAttackDamage extends CmodAttributeBaseSimple {

}
