package CoroUtil.util;

public enum EnumSpawnPlacementType
    {
        GROUND,
        SURFACE,
        CAVE,
        AIR,
        WATER,
    }