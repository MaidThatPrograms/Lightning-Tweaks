package CoroUtil.util;

import net.minecraft.entity.ai.attributes.AttributeModifier;

import java.util.UUID;

/**
 * Created by Corosus on 1/13/2017.
 */
public class CoroUtilAttributes {

    public static final UUID SPEED_BOOST_UUID = UUID.fromString("8dd7fab2-5bf6-4d07-9c0f-22b3512c1494");

    //public static AttributeModifier speedModifier = new AttributeModifier("speed multiplier boost", speedBoost, EnumAttribModifierType.MULTIPLY_ALL.ordinal());

}
