package CoroUtil.physics;

public class MatrixRotation extends MatrixCalculation {

	public MatrixRotation(double[][] parMatrixFirst, double[][] parMatrixSecond) {
		super(parMatrixFirst, parMatrixSecond);
	}
	
	@Override
	public double[][] performCalculation() {
		return super.performCalculation();
	}
	
}
