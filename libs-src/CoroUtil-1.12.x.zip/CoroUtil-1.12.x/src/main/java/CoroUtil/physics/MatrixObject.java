package CoroUtil.physics;

public class MatrixObject {

	public double[][] matrixData;
	
	public MatrixObject(double[][] parMatrix) {
		matrixData = parMatrix;
	}
	
}
