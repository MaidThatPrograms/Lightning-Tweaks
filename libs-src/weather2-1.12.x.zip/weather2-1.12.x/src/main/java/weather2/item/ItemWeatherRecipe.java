package weather2.item;

import net.minecraft.item.Item;

public class ItemWeatherRecipe extends Item {

}
