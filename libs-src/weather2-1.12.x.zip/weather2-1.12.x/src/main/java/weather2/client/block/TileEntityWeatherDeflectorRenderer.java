package weather2.client.block;

import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;

public class TileEntityWeatherDeflectorRenderer extends TileEntitySpecialRenderer
{
    @Override
    public void render(TileEntity var1, double var2, double var4, double var6, float var8, int what, float alpha) {
    	
    	
    }
}
