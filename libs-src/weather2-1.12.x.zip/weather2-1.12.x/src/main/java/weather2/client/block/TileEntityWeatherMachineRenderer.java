package weather2.client.block;

import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntity;

public class TileEntityWeatherMachineRenderer extends TileEntitySpecialRenderer
{
    @Override
    public void render(TileEntity var1, double x, double y, double z, float var8, int destroyStage, float alpha) {
    	
    	
    }
}
