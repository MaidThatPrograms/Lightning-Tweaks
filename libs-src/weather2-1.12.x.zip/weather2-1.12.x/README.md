## Description

Minecraft Mod - Localized Weather - A rewrite of weather &amp; tornadoes with a focus on localized storm systems

Requires https://github.com/Corosauce/CoroUtil and the forge and mcp snapshot specified in build.gradle to build

## Pull requests

- Target the default branch only, that is the current actively maintained branch.
- Focus on 1 feature per branch
- Keep it clean, no unnecessary changes